// Notifications System for Admin Panel
let currentToken = null;
let notificationSound = null;
let notificationEnabled = localStorage.getItem('notificationsEnabled') === 'true';

// Initialize notifications
function initNotifications() {
    if (!messaging) {
        console.log('Firebase Messaging not available');
        return;
    }

    // Register service worker
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('../firebase-messaging-sw.js')
            .then((registration) => {
                console.log('Service Worker registered:', registration);

                // Use service worker for messaging
                messaging.useServiceWorker(registration);

                // Request permission and get token
                requestNotificationPermission();
            })
            .catch((err) => {
                console.error('Service Worker registration failed:', err);
            });
    }

    // Handle foreground messages
    messaging.onMessage((payload) => {
        console.log('Message received in foreground:', payload);
        showOrderNotification(payload);
        playNotificationSound();
        showInAppNotification(payload);
    });
}

// Request permission
function requestNotificationPermission() {
    if (!notificationEnabled) return;

    Notification.requestPermission().then((permission) => {
        if (permission === 'granted') {
            getFCMToken();
        } else {
            console.log('Notification permission denied');
        }
    });
}

// Get FCM Token
function getFCMToken() {
    messaging.getToken({ vapidKey: 'YOUR_VAPID_KEY_HERE' }).then((token) => {
        if (token) {
            currentToken = token;
            console.log('FCM Token:', token);

            // Save token to database
            database.ref('adminTokens').push({
                token: token,
                createdAt: new Date().toISOString(),
                platform: navigator.platform
            });
        } else {
            console.log('No registration token available.');
        }
    }).catch((err) => {
        console.error('Error getting token:', err);
    });
}

// Show browser notification
function showOrderNotification(payload) {
    if (Notification.permission !== 'granted') return;

    const title = payload.notification?.title || 'طلب جديد!';
    const body = payload.notification?.body || 'وصل طلب جديد للمتجر';
    const icon = payload.notification?.icon || '../icon-192x192.png';

    const notification = new Notification(title, {
        body: body,
        icon: icon,
        badge: '../badge-72x72.png',
        tag: 'new-order',
        requireInteraction: true,
        actions: [
            { action: 'view', title: 'عرض الطلب' },
            { action: 'dismiss', title: 'إغلاق' }
        ],
        data: payload.data
    });

    notification.onclick = () => {
        window.focus();
        showTab('orders');
        notification.close();
    };
}

// Show in-app notification (for when admin is already viewing the page)
function showInAppNotification(payload) {
    const orderData = payload.data;
    if (!orderData) return;

    // Create notification popup
    const popup = document.createElement('div');
    popup.className = 'notification-popup';
    popup.innerHTML = `
        <div class="notification-popup-content">
            <div class="notification-icon">
                <i class="fas fa-bell"></i>
            </div>
            <div class="notification-body">
                <h4>${payload.notification?.title || 'طلب جديد!'}</h4>
                <p>${payload.notification?.body || ''}</p>
                <div class="notification-actions">
                    <button class="btn-view-order" onclick="viewOrderFromNotification('${orderData.orderId}')">
                        <i class="fas fa-eye"></i> عرض الطلب
                    </button>
                    <button class="btn-dismiss" onclick="this.closest('.notification-popup').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(popup);

    // Auto remove after 10 seconds
    setTimeout(() => {
        if (popup.parentNode) {
            popup.classList.add('fade-out');
            setTimeout(() => popup.remove(), 300);
        }
    }, 10000);

    // Animate in
    requestAnimationFrame(() => {
        popup.classList.add('show');
    });
}

// Play notification sound
function playNotificationSound() {
    if (!notificationSound) {
        notificationSound = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
        notificationSound.volume = 0.5;
    }

    notificationSound.play().catch(e => {
        console.log('Audio play failed:', e);
    });
}

// View order from notification
function viewOrderFromNotification(orderId) {
    document.querySelectorAll('.notification-popup').forEach(p => p.remove());
    showTab('orders');

    // Scroll to order
    setTimeout(() => {
        const orderRow = document.querySelector(`tr[data-order-id="${orderId}"]`);
        if (orderRow) {
            orderRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
            orderRow.classList.add('highlight-row');
            setTimeout(() => orderRow.classList.remove('highlight-row'), 3000);
        }
    }, 500);
}

// Toggle notifications
function toggleNotifications() {
    notificationEnabled = !notificationEnabled;
    localStorage.setItem('notificationsEnabled', notificationEnabled);

    if (notificationEnabled) {
        requestNotificationPermission();
        showToast('تم تفعيل الإشعارات');
    } else {
        showToast('تم إيقاف الإشعارات');
    }

    updateNotificationToggle();
}

// Update notification toggle button
function updateNotificationToggle() {
    const btn = document.getElementById('notification-toggle');
    if (btn) {
        btn.innerHTML = notificationEnabled 
            ? '<i class="fas fa-bell"></i> الإشعارات مفعلة'
            : '<i class="fas fa-bell-slash"></i> الإشعارات متوقفة';
        btn.classList.toggle('active', notificationEnabled);
    }
}

// Listen for new orders and send notification
function listenForNewOrders() {
    let lastOrderCount = 0;

    database.ref('orders').on('value', (snapshot) => {
        const orders = [];
        snapshot.forEach(child => {
            orders.push({ id: child.key, ...child.val() });
        });

        // If new orders added
        if (lastOrderCount > 0 && orders.length > lastOrderCount) {
            const newOrder = orders[orders.length - 1];

            // Show in-app notification
            showInAppNotification({
                notification: {
                    title: 'طلب جديد! 🛒',
                    body: `طلب من ${newOrder.customer?.name || 'عميل جديد'} - ${newOrder.total || 0} ج.م`
                },
                data: {
                    orderId: newOrder.id
                }
            });

            playNotificationSound();
        }

        lastOrderCount = orders.length;
    });
}

// Initialize when admin dashboard loads
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('admin-dashboard')) {
        initNotifications();
        listenForNewOrders();
        updateNotificationToggle();
    }
});
