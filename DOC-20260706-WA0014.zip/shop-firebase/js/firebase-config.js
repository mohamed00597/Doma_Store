// Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyCo5LlBsxOsZ7K4RtQitI7fgpYymgG4r0s",
    authDomain: "my-store-bf8a3.firebaseapp.com",
    databaseURL: "https://my-store-bf8a3-default-rtdb.firebaseio.com",
    projectId: "my-store-bf8a3",
    storageBucket: "my-store-bf8a3.firebasestorage.app",
    messagingSenderId: "153177906323",
    appId: "1:153177906323:web:59f9f4840cc1bce5f40166",
    measurementId: "G-WF08RGDNPP"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const database = firebase.database();
const storage = firebase.storage();

// Initialize Messaging (for notifications)
let messaging = null;
try {
    messaging = firebase.messaging();
} catch(e) {
    console.log('Messaging not available');
}
