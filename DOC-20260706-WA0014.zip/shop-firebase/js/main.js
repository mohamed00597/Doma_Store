// Global State
let storeSettings = {};
let products = [];
let sections = [];
let heroImages = [];
let cart = JSON.parse(localStorage.getItem('cart')) || [];
let favorites = JSON.parse(localStorage.getItem('favorites')) || [];
let currentProduct = null;
let selectedColor = null;
let selectedSize = null;
let appliedCoupon = JSON.parse(localStorage.getItem('appliedCoupon')) || null;
let discountAmount = 0;

// Initialize
window.addEventListener('DOMContentLoaded', () => {
    loadStoreSettings();
    loadHeroImages();
    loadSections();
    loadProducts();
    updateCartCount();
    updateFavCount();

    // Splash screen timeout
    setTimeout(() => {
        document.getElementById('splash-screen').style.display = 'none';
        document.getElementById('main-content').style.display = 'block';
    }, 3000);
});

// Load Store Settings
function loadStoreSettings() {
    database.ref('settings').on('value', (snapshot) => {
        storeSettings = snapshot.val() || {};

        // Splash screen
        document.getElementById('splash-title').textContent = storeSettings.storeName || 'متجرنا';
        if (storeSettings.logo) {
            document.getElementById('splash-logo').src = storeSettings.logo;
            document.getElementById('header-logo').src = storeSettings.logo;
        }

        // Header
        document.getElementById('header-title').textContent = storeSettings.storeName || 'متجرنا';

        // Footer links
        if (storeSettings.whatsapp) {
            document.getElementById('whatsapp-number').textContent = storeSettings.whatsapp;
            document.getElementById('whatsapp-link').href = `https://wa.me/${storeSettings.whatsapp.replace(/\D/g, '')}`;
        }
        if (storeSettings.facebook) {
            document.getElementById('facebook-link').href = storeSettings.facebook;
        }
        if (storeSettings.instagram) {
            document.getElementById('instagram-link').href = storeSettings.instagram;
        }

        // Update page title
        document.title = storeSettings.storeName || 'متجرنا الإلكتروني';
    });
}

// Load Hero Images
function loadHeroImages() {
    database.ref('heroImages').on('value', (snapshot) => {
        heroImages = [];
        snapshot.forEach((child) => {
            heroImages.push(child.val());
        });
        renderHeroSlider();
    });
}

// Render Hero Slider
function renderHeroSlider() {
    const slider = document.getElementById('hero-slider');
    if (heroImages.length === 0) {
        slider.style.display = 'none';
        return;
    }

    let html = '';
    heroImages.forEach((img, index) => {
        html += `
            <div class="hero-slide ${index === 0 ? 'active' : ''}">
                <img src="${img}" alt="Hero ${index + 1}">
            </div>
        `;
    });

    // Dots
    html += '<div class="hero-dots">';
    heroImages.forEach((_, index) => {
        html += `<div class="hero-dot ${index === 0 ? 'active' : ''}" onclick="goToSlide(${index})"></div>`;
    });
    html += '</div>';

    slider.innerHTML = html;
    slider.style.display = 'block';

    // Auto slide
    startAutoSlide();
}

let currentSlide = 0;
let slideInterval;

function startAutoSlide() {
    if (slideInterval) clearInterval(slideInterval);
    slideInterval = setInterval(() => {
        currentSlide = (currentSlide + 1) % heroImages.length;
        goToSlide(currentSlide);
    }, 5000);
}

function goToSlide(index) {
    currentSlide = index;
    const slides = document.querySelectorAll('.hero-slide');
    const dots = document.querySelectorAll('.hero-dot');

    slides.forEach((slide, i) => {
        slide.classList.toggle('active', i === index);
    });
    dots.forEach((dot, i) => {
        dot.classList.toggle('active', i === index);
    });
}

// Load Sections
function loadSections() {
    database.ref('sections').on('value', (snapshot) => {
        sections = [];
        snapshot.forEach((child) => {
            sections.push({ id: child.key, ...child.val() });
        });
        renderSections();
    });
}

// Render Sections
function renderSections() {
    const container = document.getElementById('sections-container');
    if (sections.length === 0) {
        container.style.display = 'none';
        return;
    }

    container.style.display = 'block';
    container.innerHTML = sections.map(section => `
        <div class="section-card">
            <img class="section-image" src="${section.image || 'https://via.placeholder.com/800x200'}" alt="${section.title}">
            <div class="section-info">
                <h3>${section.title}</h3>
                <p>${section.description || ''}</p>
            </div>
        </div>
    `).join('');
}

// Load Products
function loadProducts() {
    database.ref('products').on('value', (snapshot) => {
        products = [];
        snapshot.forEach((child) => {
            const product = child.val();
            if (product.active !== false) {
                products.push({ id: child.key, ...product });
            }
        });
        renderProducts();
    });
}

// Render Products
function renderProducts() {
    const grid = document.getElementById('products-grid');

    if (products.length === 0) {
        grid.innerHTML = `
            <div class="empty-state" style="grid-column: 1/-1;">
                <i class="fas fa-box-open"></i>
                <p>لا توجد منتجات متاحة حالياً</p>
            </div>
        `;
        return;
    }

    grid.innerHTML = products.map(product => {
        const hasDiscount = product.oldPrice && product.oldPrice > product.price;
        const badge = product.comingSoon 
            ? '<span class="product-badge coming-soon">سيتوفر قريباً</span>' 
            : (product.soldOut ? '<span class="product-badge sold-out">نفذت الكمية</span>' : '');

        const colorsHtml = product.colors ? product.colors.map(c => 
            `<span class="color-dot" style="background-color: ${c.code};"></span>`
        ).join('') : '';

        const sizesHtml = product.sizes ? product.sizes.map(s => 
            `<span class="size-tag">${s}</span>`
        ).join('') : '';

        return `
            <div class="product-card" onclick="openProductModal('${product.id}')">
                <div class="product-image">
                    <img src="${product.images?.[0] || 'https://via.placeholder.com/300x250'}" alt="${product.name}">
                    ${badge}
                </div>
                <div class="product-info">
                    <h3 class="product-name">${product.name}</h3>
                    ${colorsHtml ? `<div class="product-colors">${colorsHtml}</div>` : ''}
                    ${sizesHtml ? `<div class="product-sizes">${sizesHtml}</div>` : ''}
                    <div class="price-section">
                        ${hasDiscount ? `<span class="old-price">${product.oldPrice} ج.م</span>` : ''}
                        <span class="current-price">${product.price} ج.م</span>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

// Open Product Modal
function openProductModal(productId) {
    currentProduct = products.find(p => p.id === productId);
    if (!currentProduct) return;

    selectedColor = null;
    selectedSize = null;

    // Main image
    document.getElementById('modal-main-image').src = currentProduct.images?.[0] || '';

    // Thumbnails
    const thumbnailsContainer = document.getElementById('modal-thumbnails');
    if (currentProduct.images && currentProduct.images.length > 1) {
        thumbnailsContainer.innerHTML = currentProduct.images.map((img, i) => `
            <div class="thumbnail ${i === 0 ? 'active' : ''}" onclick="changeMainImage('${img}', this)">
                <img src="${img}" alt="">
            </div>
        `).join('');
    } else {
        thumbnailsContainer.innerHTML = '';
    }

    // Product info
    document.getElementById('modal-product-name').textContent = currentProduct.name;
    document.getElementById('modal-old-price').textContent = currentProduct.oldPrice ? `${currentProduct.oldPrice} ج.م` : '';
    document.getElementById('modal-old-price').style.display = currentProduct.oldPrice ? 'inline' : 'none';
    document.getElementById('modal-current-price').textContent = `${currentProduct.price} ج.م`;

    // Colors
    const colorsSection = document.getElementById('modal-colors-section');
    const colorsContainer = document.getElementById('modal-colors');
    if (currentProduct.colors && currentProduct.colors.length > 0) {
        colorsSection.style.display = 'block';
        colorsContainer.innerHTML = currentProduct.colors.map((color, i) => `
            <div class="color-option ${color.available === false ? 'disabled' : ''}" 
                 onclick="selectColor('${color.name}', '${color.code}', this)">
                <span class="color-preview" style="background-color: ${color.code};"></span>
                <span>${color.name}</span>
            </div>
        `).join('');
    } else {
        colorsSection.style.display = 'none';
    }

    // Sizes
    const sizesSection = document.getElementById('modal-sizes-section');
    const sizesContainer = document.getElementById('modal-sizes');
    if (currentProduct.sizes && currentProduct.sizes.length > 0) {
        sizesSection.style.display = 'block';
        sizesContainer.innerHTML = currentProduct.sizes.map(size => `
            <div class="size-option ${size.available === false ? 'disabled' : ''}" 
                 onclick="selectSize('${size.name || size}', this)">
                ${size.name || size}
            </div>
        `).join('');
    } else {
        sizesSection.style.display = 'none';
    }

    // Update favorite button
    updateFavButton();

    document.getElementById('product-modal').classList.add('active');
}

// Change Main Image
function changeMainImage(src, thumb) {
    document.getElementById('modal-main-image').src = src;
    document.querySelectorAll('.thumbnail').forEach(t => t.classList.remove('active'));
    thumb.classList.add('active');
}

// Select Color
function selectColor(name, code, el) {
    if (el.classList.contains('disabled')) return;
    selectedColor = { name, code };
    document.querySelectorAll('.color-option').forEach(opt => opt.classList.remove('selected'));
    el.classList.add('selected');
}

// Select Size
function selectSize(size, el) {
    if (el.classList.contains('disabled')) return;
    selectedSize = size;
    document.querySelectorAll('.size-option').forEach(opt => opt.classList.remove('selected'));
    el.classList.add('selected');
}

// Close Modal
function closeModal() {
    document.getElementById('product-modal').classList.remove('active');
    currentProduct = null;
}

// Toggle Favorite
function toggleFavorite() {
    if (!currentProduct) return;

    const index = favorites.findIndex(f => f.id === currentProduct.id);
    if (index > -1) {
        favorites.splice(index, 1);
        showToast('تم إزالة المنتج من المفضلة');
    } else {
        favorites.push({
            id: currentProduct.id,
            name: currentProduct.name,
            image: currentProduct.images?.[0],
            price: currentProduct.price
        });
        showToast('تم إضافة المنتج للمفضلة');
    }

    localStorage.setItem('favorites', JSON.stringify(favorites));
    updateFavButton();
    updateFavCount();
}

function updateFavButton() {
    const btn = document.querySelector('.btn-fav');
    const isFav = currentProduct && favorites.some(f => f.id === currentProduct.id);
    btn.innerHTML = `<i class="${isFav ? 'fas' : 'far'} fa-heart"></i> ${isFav ? 'في المفضلة' : 'المفضلة'}`;
    btn.style.color = isFav ? '#e74c3c' : '';
}

// Add to Cart
function addToCart() {
    if (!currentProduct) return;

    if (currentProduct.colors?.length > 0 && !selectedColor) {
        showToast('الرجاء اختيار اللون');
        return;
    }
    if (currentProduct.sizes?.length > 0 && !selectedSize) {
        showToast('الرجاء اختيار المقاس');
        return;
    }

    const cartItem = {
        id: currentProduct.id,
        name: currentProduct.name,
        image: currentProduct.images?.[0],
        price: currentProduct.price,
        color: selectedColor,
        size: selectedSize,
        quantity: 1
    };

    // Check if already in cart
    const existingIndex = cart.findIndex(c => 
        c.id === cartItem.id && 
        c.color?.name === cartItem.color?.name && 
        c.size === cartItem.size
    );

    if (existingIndex > -1) {
        cart[existingIndex].quantity++;
    } else {
        cart.push(cartItem);
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    showToast('تم إضافة المنتج للسلة');
    closeModal();
}

// Quick Order
function quickOrder() {
    if (!currentProduct) return;

    if (currentProduct.colors?.length > 0 && !selectedColor) {
        showToast('الرجاء اختيار اللون');
        return;
    }
    if (currentProduct.sizes?.length > 0 && !selectedSize) {
        showToast('الرجاء اختيار المقاس');
        return;
    }

    // Add to cart first
    const cartItem = {
        id: currentProduct.id,
        name: currentProduct.name,
        image: currentProduct.images?.[0],
        price: currentProduct.price,
        color: selectedColor,
        size: selectedSize,
        quantity: 1
    };

    const existingIndex = cart.findIndex(c => 
        c.id === cartItem.id && 
        c.color?.name === cartItem.color?.name && 
        c.size === cartItem.size
    );

    if (existingIndex > -1) {
        cart[existingIndex].quantity++;
    } else {
        cart.push(cartItem);
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();

    closeModal();
    showOrderModal();
}

// Show Order Modal
function showOrderModal() {
    const summary = document.getElementById('order-summary');
    let subtotal = 0;

    let html = cart.map(item => {
        const itemTotal = item.price * item.quantity;
        subtotal += itemTotal;
        return `
            <div class="order-summary-item">
                <span>${item.name} ${item.color ? `(${item.color.name})` : ''} ${item.size ? `(${item.size})` : ''} x${item.quantity}</span>
                <span>${itemTotal} ج.م</span>
            </div>
        `;
    }).join('');

    // Calculate discount
    discountAmount = 0;
    if (appliedCoupon) {
        if (appliedCoupon.type === 'percentage') {
            discountAmount = subtotal * (appliedCoupon.value / 100);
        } else if (appliedCoupon.type === 'fixed') {
            discountAmount = appliedCoupon.value;
        }
        if (discountAmount > subtotal) discountAmount = subtotal;
    }

    const finalTotal = subtotal - discountAmount;

    if (discountAmount > 0) {
        html += `<div class="order-summary-item" style="color: var(--gray);"><span>الإجمالي</span><span>${subtotal} ج.م</span></div>`;
        html += `<div class="order-summary-item" style="color: var(--success);"><span>خصم (${appliedCoupon.code})</span><span>-${Math.round(discountAmount)} ج.م</span></div>`;
    }

    html += `
        <div class="order-summary-total">
            <span>الإجمالي النهائي</span>
            <span>${Math.round(finalTotal)} ج.م</span>
        </div>
    `;

    summary.innerHTML = html;
    document.getElementById('order-modal').classList.add('active');
}

// Close Order Modal
function closeOrderModal() {
    document.getElementById('order-modal').classList.remove('active');
}

// Cancel Order
function cancelOrder() {
    closeOrderModal();
    showToast('تم إلغاء الطلب');
}

// Submit Order
function submitOrder(e) {
    e.preventDefault();

    const name = document.getElementById('order-name').value;
    const phone = document.getElementById('order-phone').value;
    const address = document.getElementById('order-address').value;
    const notes = document.getElementById('order-notes').value;

    if (!name || !phone || !address) {
        showToast('الرجاء ملء جميع الحقول المطلوبة');
        return;
    }

    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    const order = {
        customer: { name, phone, address, notes },
        items: cart,
        subtotal: subtotal,
        discount: Math.round(discountAmount),
        coupon: appliedCoupon ? appliedCoupon.code : null,
        total: Math.round(subtotal - discountAmount),
        status: 'pending',
        createdAt: new Date().toISOString()
    };

    database.ref('orders').push(order)
        .then(() => {
            // Increment coupon usage if applied
            if (appliedCoupon) {
                database.ref('coupons/' + appliedCoupon.code + '/usedCount').transaction(count => (count || 0) + 1);
            }

            showToast('تم إرسال الطلب بنجاح!');
            cart = [];
            appliedCoupon = null;
            discountAmount = 0;
            localStorage.setItem('cart', JSON.stringify(cart));
            localStorage.removeItem('appliedCoupon');
            updateCartCount();
            closeOrderModal();
            document.getElementById('order-form').reset();
        })
        .catch((error) => {
            showToast('حدث خطأ أثناء إرسال الطلب');
            console.error(error);
        });
}

document.getElementById('order-form').addEventListener('submit', submitOrder);

// Cart Functions
function showCart() {
    const container = document.getElementById('cart-items');

    if (cart.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-shopping-cart"></i>
                <p>السلة فارغة</p>
            </div>
        `;
        document.getElementById('cart-total-price').textContent = '0 ج.م';
        document.getElementById('cart-coupon-section').style.display = 'none';
    } else {
        let subtotal = 0;
        container.innerHTML = cart.map((item, index) => {
            const itemTotal = item.price * item.quantity;
            subtotal += itemTotal;
            return `
                <div class="cart-item">
                    <img src="${item.image || 'https://via.placeholder.com/80'}" alt="${item.name}">
                    <div class="cart-item-info">
                        <h4>${item.name}</h4>
                        <p>${item.color ? item.color.name : ''} ${item.size ? item.size : ''}</p>
                        <p>الكمية: ${item.quantity}</p>
                    </div>
                    <div class="cart-item-price">${itemTotal} ج.م</div>
                    <button class="remove-btn" onclick="removeFromCart(${index})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
        }).join('');

        // Calculate totals with coupon
        discountAmount = 0;
        if (appliedCoupon) {
            if (appliedCoupon.type === 'percentage') {
                discountAmount = subtotal * (appliedCoupon.value / 100);
            } else if (appliedCoupon.type === 'fixed') {
                discountAmount = appliedCoupon.value;
            }
            if (discountAmount > subtotal) discountAmount = subtotal;
        }

        const finalTotal = subtotal - discountAmount;

        // Update coupon display
        const couponSection = document.getElementById('cart-coupon-section');
        couponSection.style.display = 'block';

        if (appliedCoupon) {
            document.getElementById('coupon-input').value = appliedCoupon.code;
            document.getElementById('coupon-message').innerHTML = 
                `<span class="coupon-success">✓ كوبون "${appliedCoupon.code}" مفعل! خصم ${appliedCoupon.value}${appliedCoupon.type === 'percentage' ? '%' : ' ج.م'}</span>`;
            document.getElementById('coupon-btn').textContent = 'إلغاء';
            document.getElementById('coupon-btn').onclick = removeCoupon;
        } else {
            document.getElementById('coupon-input').value = '';
            document.getElementById('coupon-message').innerHTML = '';
            document.getElementById('coupon-btn').textContent = 'تطبيق';
            document.getElementById('coupon-btn').onclick = applyCoupon;
        }

        // Update total display
        let totalHtml = '';
        if (discountAmount > 0) {
            totalHtml += `<div class="cart-subtotal">الإجمالي: ${subtotal} ج.م</div>`;
            totalHtml += `<div class="cart-discount">الخصم: -${Math.round(discountAmount)} ج.م</div>`;
        }
        totalHtml += `<span>${Math.round(finalTotal)} ج.م</span>`;
        document.getElementById('cart-total-price').innerHTML = totalHtml;
    }

    document.getElementById('cart-modal').classList.add('active');
}

function closeCartModal() {
    document.getElementById('cart-modal').classList.remove('active');
}

function removeFromCart(index) {
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    showCart();
    showToast('تم إزالة المنتج من السلة');
}

function checkoutFromCart() {
    if (cart.length === 0) {
        showToast('السلة فارغة');
        return;
    }
    closeCartModal();
    showOrderModal();
}

// Coupon Functions
function applyCoupon() {
    const code = document.getElementById('coupon-input').value.trim().toUpperCase();
    if (!code) {
        showToast('الرجاء إدخال كود الكوبون');
        return;
    }

    database.ref('coupons/' + code).once('value').then((snapshot) => {
        const coupon = snapshot.val();

        if (!coupon) {
            document.getElementById('coupon-message').innerHTML = '<span class="coupon-error">✗ كوبون غير صالح</span>';
            return;
        }

        if (!coupon.active) {
            document.getElementById('coupon-message').innerHTML = '<span class="coupon-error">✗ الكوبون غير مفعل</span>';
            return;
        }

        if (coupon.expiresAt && new Date(coupon.expiresAt) < new Date()) {
            document.getElementById('coupon-message').innerHTML = '<span class="coupon-error">✗ الكوبون منتهي الصلاحية</span>';
            return;
        }

        if (coupon.minOrder) {
            const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
            if (subtotal < coupon.minOrder) {
                document.getElementById('coupon-message').innerHTML = `<span class="coupon-error">✗ الحد الأدنى للطلب ${coupon.minOrder} ج.م</span>`;
                return;
            }
        }

        if (coupon.maxUses && coupon.usedCount >= coupon.maxUses) {
            document.getElementById('coupon-message').innerHTML = '<span class="coupon-error">✗ الكوبون استنفذ استخداماته</span>';
            return;
        }

        appliedCoupon = {
            code: code,
            type: coupon.type,
            value: coupon.value
        };
        localStorage.setItem('appliedCoupon', JSON.stringify(appliedCoupon));

        document.getElementById('coupon-message').innerHTML = 
            `<span class="coupon-success">✓ كوبون "${code}" مفعل! خصم ${coupon.value}${coupon.type === 'percentage' ? '%' : ' ج.م'}</span>`;
        document.getElementById('coupon-btn').textContent = 'إلغاء';
        document.getElementById('coupon-btn').onclick = removeCoupon;

        showCart(); // Refresh to show discount
        showToast('تم تطبيق الكوبون بنجاح!');
    });
}

function removeCoupon() {
    appliedCoupon = null;
    discountAmount = 0;
    localStorage.removeItem('appliedCoupon');
    document.getElementById('coupon-input').value = '';
    document.getElementById('coupon-message').innerHTML = '';
    document.getElementById('coupon-btn').textContent = 'تطبيق';
    document.getElementById('coupon-btn').onclick = applyCoupon;
    showCart();
    showToast('تم إزالة الكوبون');
}

// Favorites Functions
function showFavorites() {
    const container = document.getElementById('fav-items');

    if (favorites.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-heart"></i>
                <p>لا توجد منتجات في المفضلة</p>
            </div>
        `;
    } else {
        container.innerHTML = favorites.map((item, index) => `
            <div class="fav-item">
                <img src="${item.image || 'https://via.placeholder.com/80'}" alt="${item.name}">
                <div class="fav-item-info">
                    <h4>${item.name}</h4>
                    <p>${item.price} ج.م</p>
                </div>
                <button class="remove-btn" onclick="removeFromFavorites(${index})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `).join('');
    }

    document.getElementById('fav-modal').classList.add('active');
}

function closeFavModal() {
    document.getElementById('fav-modal').classList.remove('active');
}

function removeFromFavorites(index) {
    favorites.splice(index, 1);
    localStorage.setItem('favorites', JSON.stringify(favorites));
    updateFavCount();
    showFavorites();
    showToast('تم إزالة المنتج من المفضلة');
}

// Update Counts
function updateCartCount() {
    const count = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.getElementById('cart-count').textContent = count;
}

function updateFavCount() {
    document.getElementById('fav-count').textContent = favorites.length;
}

// Toast
function showToast(message) {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.classList.add('show');

    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// Close modals on backdrop click
document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('active');
        }
    });
});
