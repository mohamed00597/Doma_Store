// Admin State
let adminPassword = '123456';
let currentTab = 'settings';
let sections = [];
let products = [];
let orders = [];
let heroImages = [];
let uploadedProductImages = [];

// Check Login
window.addEventListener('DOMContentLoaded', () => {
    const isLoggedIn = sessionStorage.getItem('adminLoggedIn');
    if (isLoggedIn === 'true') {
        showDashboard();
    }
});

// Login
document.getElementById('login-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const password = document.getElementById('admin-password').value;
    if (password === adminPassword) {
        sessionStorage.setItem('adminLoggedIn', 'true');
        showDashboard();
    } else {
        showToast('كلمة المرور غير صحيحة');
    }
});

function showDashboard() {
    document.getElementById('login-screen').style.display = 'none';
    document.getElementById('admin-dashboard').style.display = 'flex';
    loadSettings();
    loadHeroImages();
    loadSections();
    loadProducts();
    loadCoupons();
    loadOrders();
}

function logout() {
    sessionStorage.removeItem('adminLoggedIn');
    location.reload();
}

// Tab Navigation
function showTab(tab) {
    currentTab = tab;

    // Update nav
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.toggle('active', item.getAttribute('href') === '#' + tab);
    });

    // Update content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById('tab-' + tab).classList.add('active');

    // Update title
    const titles = {
        settings: 'إعدادات المتجر',
        hero: 'صور العرض الرئيسية',
        sections: 'الأقسام',
        products: 'المنتجات',
        coupons: 'كوبونات الخصم',
        orders: 'الطلبات'
    };
    document.getElementById('page-title').textContent = titles[tab];
}

// ==================== SETTINGS ====================
function loadSettings() {
    database.ref('settings').on('value', (snapshot) => {
        const settings = snapshot.val() || {};
        document.getElementById('setting-storeName').value = settings.storeName || '';
        document.getElementById('setting-whatsapp').value = settings.whatsapp || '';
        document.getElementById('setting-facebook').value = settings.facebook || '';
        document.getElementById('setting-instagram').value = settings.instagram || '';

        if (settings.logo) {
            document.getElementById('logo-preview').innerHTML = `<img src="${settings.logo}" alt="Logo">`;
            document.getElementById('setting-logo-url').value = settings.logo;
        }
    });
}

document.getElementById('settings-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const settings = {
        storeName: document.getElementById('setting-storeName').value,
        whatsapp: document.getElementById('setting-whatsapp').value,
        facebook: document.getElementById('setting-facebook').value,
        instagram: document.getElementById('setting-instagram').value,
        logo: document.getElementById('setting-logo-url').value
    };

    database.ref('settings').set(settings)
        .then(() => showToast('تم حفظ الإعدادات بنجاح'))
        .catch(err => showToast('حدث خطأ: ' + err.message));
});

// Upload Logo
function uploadLogo(input) {
    const file = input.files[0];
    if (!file) return;

    const storageRef = storage.ref('logos/' + Date.now() + '_' + file.name);
    storageRef.put(file).then(snapshot => {
        return snapshot.ref.getDownloadURL();
    }).then(url => {
        document.getElementById('logo-preview').innerHTML = `<img src="${url}" alt="Logo">`;
        document.getElementById('setting-logo-url').value = url;
        showToast('تم رفع الشعار بنجاح');
    }).catch(err => {
        showToast('حدث خطأ في الرفع: ' + err.message);
    });
}

// ==================== HERO IMAGES ====================
function loadHeroImages() {
    database.ref('heroImages').on('value', (snapshot) => {
        heroImages = [];
        snapshot.forEach(child => {
            heroImages.push({ id: child.key, url: child.val() });
        });
        renderHeroImages();
    });
}

function renderHeroImages() {
    const grid = document.getElementById('hero-images-grid');
    if (heroImages.length === 0) {
        grid.innerHTML = '<p style="color: var(--gray); text-align: center;">لا توجد صور</p>';
        return;
    }

    grid.innerHTML = heroImages.map(img => `
        <div class="image-item">
            <img src="${img.url}" alt="Hero">
            <button class="delete-btn" onclick="deleteHeroImage('${img.id}')">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `).join('');
}

function uploadHeroImages(input) {
    const files = Array.from(input.files);
    if (files.length === 0) return;

    let uploaded = 0;
    files.forEach(file => {
        const storageRef = storage.ref('hero/' + Date.now() + '_' + file.name);
        storageRef.put(file).then(snapshot => {
            return snapshot.ref.getDownloadURL();
        }).then(url => {
            database.ref('heroImages').push(url);
            uploaded++;
            if (uploaded === files.length) {
                showToast(`تم رفع ${uploaded} صورة بنجاح`);
                input.value = '';
            }
        }).catch(err => {
            showToast('حدث خطأ: ' + err.message);
        });
    });
}

function deleteHeroImage(id) {
    if (!confirm('هل أنت متأكد من حذف هذه الصورة؟')) return;
    database.ref('heroImages/' + id).remove()
        .then(() => showToast('تم الحذف بنجاح'))
        .catch(err => showToast('حدث خطأ: ' + err.message));
}

// ==================== SECTIONS ====================
function loadSections() {
    database.ref('sections').on('value', (snapshot) => {
        sections = [];
        snapshot.forEach(child => {
            sections.push({ id: child.key, ...child.val() });
        });
        renderSectionsTable();
    });
}

function renderSectionsTable() {
    const tbody = document.getElementById('sections-table');
    if (sections.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: var(--gray);">لا توجد أقسام</td></tr>';
        return;
    }

    tbody.innerHTML = sections.map(section => `
        <tr>
            <td><img src="${section.image || 'https://via.placeholder.com/60'}" alt="${section.title}"></td>
            <td>${section.title}</td>
            <td>${section.description || '-'}</td>
            <td class="table-actions">
                <button class="btn-edit" onclick="editSection('${section.id}')">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn-delete" onclick="deleteSection('${section.id}')">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

function openSectionModal() {
    document.getElementById('section-id').value = '';
    document.getElementById('section-title').value = '';
    document.getElementById('section-description').value = '';
    document.getElementById('section-image-url').value = '';
    document.getElementById('section-image-preview').innerHTML = `
        <i class="fas fa-cloud-upload-alt"></i>
        <span>اختر صورة</span>
    `;
    document.getElementById('section-modal').classList.add('active');
}

function closeSectionModal() {
    document.getElementById('section-modal').classList.remove('active');
}

function editSection(id) {
    const section = sections.find(s => s.id === id);
    if (!section) return;

    document.getElementById('section-id').value = id;
    document.getElementById('section-title').value = section.title;
    document.getElementById('section-description').value = section.description || '';
    document.getElementById('section-image-url').value = section.image || '';

    if (section.image) {
        document.getElementById('section-image-preview').innerHTML = `<img src="${section.image}" alt="${section.title}">`;
    }

    document.getElementById('section-modal').classList.add('active');
}

function deleteSection(id) {
    if (!confirm('هل أنت متأكد من حذف هذا القسم؟')) return;
    database.ref('sections/' + id).remove()
        .then(() => showToast('تم الحذف بنجاح'))
        .catch(err => showToast('حدث خطأ: ' + err.message));
}

function uploadSectionImage(input) {
    const file = input.files[0];
    if (!file) return;

    const storageRef = storage.ref('sections/' + Date.now() + '_' + file.name);
    storageRef.put(file).then(snapshot => {
        return snapshot.ref.getDownloadURL();
    }).then(url => {
        document.getElementById('section-image-preview').innerHTML = `<img src="${url}" alt="Section">`;
        document.getElementById('section-image-url').value = url;
        showToast('تم رفع الصورة بنجاح');
    }).catch(err => {
        showToast('حدث خطأ في الرفع: ' + err.message);
    });
}

document.getElementById('section-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const id = document.getElementById('section-id').value;
    const sectionData = {
        title: document.getElementById('section-title').value,
        description: document.getElementById('section-description').value,
        image: document.getElementById('section-image-url').value
    };

    const ref = id ? database.ref('sections/' + id) : database.ref('sections').push();
    ref.set(sectionData)
        .then(() => {
            showToast(id ? 'تم التحديث بنجاح' : 'تم الإضافة بنجاح');
            closeSectionModal();
        })
        .catch(err => showToast('حدث خطأ: ' + err.message));
});

// ==================== PRODUCTS ====================
function loadProducts() {
    database.ref('products').on('value', (snapshot) => {
        products = [];
        snapshot.forEach(child => {
            products.push({ id: child.key, ...child.val() });
        });
        renderProductsTable();
    });
}

function renderProductsTable() {
    const tbody = document.getElementById('products-table');
    if (products.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; color: var(--gray);">لا توجد منتجات</td></tr>';
        return;
    }

    tbody.innerHTML = products.map(product => {
        const status = product.active === false ? 'معطل' : 
                      (product.comingSoon ? 'قريباً' : 
                      (product.soldOut ? 'نفذت' : 'نشط'));
        const statusClass = product.active === false ? 'status-cancelled' : 
                           (product.comingSoon ? 'status-processing' : 
                           (product.soldOut ? 'status-pending' : 'status-completed'));

        return `
            <tr>
                <td><img src="${product.images?.[0] || 'https://via.placeholder.com/60'}" alt="${product.name}"></td>
                <td>${product.name}</td>
                <td>${product.price} ج.م</td>
                <td><span class="status-badge ${statusClass}">${status}</span></td>
                <td class="table-actions">
                    <button class="btn-edit" onclick="editProduct('${product.id}')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-delete" onclick="deleteProduct('${product.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                    <button class="btn-toggle ${product.active !== false ? 'active' : ''}" onclick="toggleProduct('${product.id}')">
                        <i class="fas fa-power-off"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

function openProductModal() {
    document.getElementById('product-id').value = '';
    document.getElementById('product-name').value = '';
    document.getElementById('product-price').value = '';
    document.getElementById('product-old-price').value = '';
    document.getElementById('product-active').checked = true;
    document.getElementById('product-coming-soon').checked = false;
    document.getElementById('product-sold-out').checked = false;

    uploadedProductImages = [];
    document.getElementById('product-images-preview').innerHTML = '';

    // Reset colors
    document.getElementById('colors-container').innerHTML = `
        <div class="color-input-row">
            <input type="text" placeholder="اسم اللون" class="color-name">
            <input type="color" class="color-code" value="#000000">
            <label class="checkbox-label">
                <input type="checkbox" class="color-available" checked>
                متوفر
            </label>
            <button type="button" class="btn-remove-row" onclick="removeColorRow(this)">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;

    // Reset sizes
    document.getElementById('sizes-container').innerHTML = `
        <div class="size-input-row">
            <input type="text" placeholder="المقاس (مثال: M, L, XL)" class="size-name">
            <label class="checkbox-label">
                <input type="checkbox" class="size-available" checked>
                متوفر
            </label>
            <button type="button" class="btn-remove-row" onclick="removeSizeRow(this)">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;

    document.getElementById('product-modal').classList.add('active');
}

function closeProductModal() {
    document.getElementById('product-modal').classList.remove('active');
}

function editProduct(id) {
    const product = products.find(p => p.id === id);
    if (!product) return;

    document.getElementById('product-id').value = id;
    document.getElementById('product-name').value = product.name;
    document.getElementById('product-price').value = product.price;
    document.getElementById('product-old-price').value = product.oldPrice || '';
    document.getElementById('product-active').checked = product.active !== false;
    document.getElementById('product-coming-soon').checked = product.comingSoon || false;
    document.getElementById('product-sold-out').checked = product.soldOut || false;

    // Images
    uploadedProductImages = product.images || [];
    renderProductImagesPreview();

    // Colors
    if (product.colors && product.colors.length > 0) {
        document.getElementById('colors-container').innerHTML = product.colors.map(color => `
            <div class="color-input-row">
                <input type="text" placeholder="اسم اللون" class="color-name" value="${color.name}">
                <input type="color" class="color-code" value="${color.code}">
                <label class="checkbox-label">
                    <input type="checkbox" class="color-available" ${color.available !== false ? 'checked' : ''}>
                    متوفر
                </label>
                <button type="button" class="btn-remove-row" onclick="removeColorRow(this)">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `).join('');
    }

    // Sizes
    if (product.sizes && product.sizes.length > 0) {
        document.getElementById('sizes-container').innerHTML = product.sizes.map(size => `
            <div class="size-input-row">
                <input type="text" placeholder="المقاس" class="size-name" value="${size.name || size}">
                <label class="checkbox-label">
                    <input type="checkbox" class="size-available" ${size.available !== false ? 'checked' : ''}>
                    متوفر
                </label>
                <button type="button" class="btn-remove-row" onclick="removeSizeRow(this)">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `).join('');
    }

    document.getElementById('product-modal').classList.add('active');
}

function deleteProduct(id) {
    if (!confirm('هل أنت متأكد من حذف هذا المنتج؟')) return;
    database.ref('products/' + id).remove()
        .then(() => showToast('تم الحذف بنجاح'))
        .catch(err => showToast('حدث خطأ: ' + err.message));
}

function toggleProduct(id) {
    const product = products.find(p => p.id === id);
    if (!product) return;

    const newActive = product.active === false ? true : false;
    database.ref('products/' + id + '/active').set(newActive)
        .then(() => showToast(newActive ? 'تم تفعيل المنتج' : 'تم تعطيل المنتج'))
        .catch(err => showToast('حدث خطأ: ' + err.message));
}

function uploadProductImages(input) {
    const files = Array.from(input.files);
    if (files.length === 0) return;

    let uploaded = 0;
    files.forEach(file => {
        const storageRef = storage.ref('products/' + Date.now() + '_' + file.name);
        storageRef.put(file).then(snapshot => {
            return snapshot.ref.getDownloadURL();
        }).then(url => {
            uploadedProductImages.push(url);
            uploaded++;
            renderProductImagesPreview();
            if (uploaded === files.length) {
                showToast(`تم رفع ${uploaded} صورة`);
                input.value = '';
            }
        }).catch(err => {
            showToast('حدث خطأ: ' + err.message);
        });
    });
}

function renderProductImagesPreview() {
    const preview = document.getElementById('product-images-preview');
    preview.innerHTML = uploadedProductImages.map((url, index) => `
        <div class="image-item" style="position: relative;">
            <img src="${url}" alt="Product">
            <button class="delete-btn" style="opacity: 1;" onclick="removeProductImage(${index})">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `).join('');
}

function removeProductImage(index) {
    uploadedProductImages.splice(index, 1);
    renderProductImagesPreview();
}

function addColorRow() {
    const container = document.getElementById('colors-container');
    container.insertAdjacentHTML('beforeend', `
        <div class="color-input-row">
            <input type="text" placeholder="اسم اللون" class="color-name">
            <input type="color" class="color-code" value="#000000">
            <label class="checkbox-label">
                <input type="checkbox" class="color-available" checked>
                متوفر
            </label>
            <button type="button" class="btn-remove-row" onclick="removeColorRow(this)">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `);
}

function removeColorRow(btn) {
    btn.closest('.color-input-row').remove();
}

function addSizeRow() {
    const container = document.getElementById('sizes-container');
    container.insertAdjacentHTML('beforeend', `
        <div class="size-input-row">
            <input type="text" placeholder="المقاس (مثال: M, L, XL)" class="size-name">
            <label class="checkbox-label">
                <input type="checkbox" class="size-available" checked>
                متوفر
            </label>
            <button type="button" class="btn-remove-row" onclick="removeSizeRow(this)">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `);
}

function removeSizeRow(btn) {
    btn.closest('.size-input-row').remove();
}

document.getElementById('product-form').addEventListener('submit', (e) => {
    e.preventDefault();

    // Collect colors
    const colors = [];
    document.querySelectorAll('#colors-container .color-input-row').forEach(row => {
        const name = row.querySelector('.color-name').value;
        const code = row.querySelector('.color-code').value;
        const available = row.querySelector('.color-available').checked;
        if (name) colors.push({ name, code, available });
    });

    // Collect sizes
    const sizes = [];
    document.querySelectorAll('#sizes-container .size-input-row').forEach(row => {
        const name = row.querySelector('.size-name').value;
        const available = row.querySelector('.size-available').checked;
        if (name) sizes.push({ name, available });
    });

    const id = document.getElementById('product-id').value;
    const productData = {
        name: document.getElementById('product-name').value,
        price: parseFloat(document.getElementById('product-price').value),
        oldPrice: parseFloat(document.getElementById('product-old-price').value) || null,
        images: uploadedProductImages,
        colors: colors.length > 0 ? colors : null,
        sizes: sizes.length > 0 ? sizes : null,
        active: document.getElementById('product-active').checked,
        comingSoon: document.getElementById('product-coming-soon').checked,
        soldOut: document.getElementById('product-sold-out').checked
    };

    const ref = id ? database.ref('products/' + id) : database.ref('products').push();
    ref.set(productData)
        .then(() => {
            showToast(id ? 'تم التحديث بنجاح' : 'تم الإضافة بنجاح');
            closeProductModal();
        })
        .catch(err => showToast('حدث خطأ: ' + err.message));
});

// ==================== ORDERS ====================
function loadOrders() {
    database.ref('orders').on('value', (snapshot) => {
        orders = [];
        snapshot.forEach(child => {
            orders.push({ id: child.key, ...child.val() });
        });
        renderOrdersTable();
    });
}

function renderOrdersTable() {
    // Update order counter in sidebar
    const pendingOrders = orders.filter(o => o.status === 'pending').length;
    const ordersNav = document.querySelector('a[href="#orders"]');
    if (ordersNav) {
        const existingCounter = ordersNav.querySelector('.order-counter');
        if (pendingOrders > 0) {
            if (existingCounter) {
                existingCounter.textContent = pendingOrders;
            } else {
                ordersNav.insertAdjacentHTML('beforeend', `<span class="order-counter">${pendingOrders}</span>`);
            }
        } else if (existingCounter) {
            existingCounter.remove();
        }
    }
    const tbody = document.getElementById('orders-table');
    if (orders.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; color: var(--gray);">لا توجد طلبات</td></tr>';
        return;
    }

    tbody.innerHTML = orders.map(order => {
        const date = new Date(order.createdAt).toLocaleDateString('ar-EG');
        const statusClass = 'status-' + (order.status || 'pending');
        const statusText = {
            pending: 'معلق',
            processing: 'قيد التنفيذ',
            completed: 'مكتمل',
            cancelled: 'ملغي'
        }[order.status] || 'معلق';

        return `
            <tr data-order-id="${order.id}">
                <td>#${order.id.slice(-6)}</td>
                <td>${order.customer?.name || '-'}</td>
                <td>${order.customer?.phone || '-'}</td>
                <td>${order.total || 0} ج.م</td>
                <td><span class="status-badge ${statusClass}">${statusText}</span></td>
                <td>${date}</td>
                <td class="table-actions">
                    <button class="btn-edit" onclick="viewOrder('${order.id}')">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn-delete" onclick="deleteOrder('${order.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

function viewOrder(id) {
    const order = orders.find(o => o.id === id);
    if (!order) return;

    const content = document.getElementById('order-details-content');
    content.innerHTML = `
        <div class="order-details">
            <h4>معلومات العميل</h4>
            <p><strong>الاسم:</strong> ${order.customer?.name || '-'}</p>
            <p><strong>الهاتف:</strong> ${order.customer?.phone || '-'}</p>
            <p><strong>العنوان:</strong> ${order.customer?.address || '-'}</p>
            ${order.customer?.notes ? `<p><strong>ملاحظات:</strong> ${order.customer.notes}</p>` : ''}
        </div>
        <div class="order-details">
            <h4>المنتجات</h4>
            ${order.items?.map(item => `
                <div class="order-item">
                    <span>${item.name} ${item.color ? `(${item.color.name})` : ''} ${item.size ? `(${item.size})` : ''} x${item.quantity}</span>
                    <span>${item.price * item.quantity} ج.م</span>
                </div>
            `).join('') || ''}
            ${order.subtotal ? `<div class="order-item" style="color: var(--gray);"><span>الإجمالي</span><span>${order.subtotal} ج.م</span></div>` : ''}
            ${order.discount > 0 ? `<div class="order-item" style="color: var(--success);"><span>خصم ${order.coupon ? `(${order.coupon})` : ''}</span><span>-${order.discount} ج.م</span></div>` : ''}
            <div class="order-item" style="border-top: 2px solid var(--primary); margin-top: 10px; padding-top: 10px; font-weight: 800;">
                <span>الإجمالي النهائي</span>
                <span>${order.total} ج.م</span>
            </div>
        </div>
        <div class="form-row">
            <button class="btn-save" onclick="updateOrderStatus('${id}', 'completed')">تم التسليم</button>
            <button class="btn-add" onclick="updateOrderStatus('${id}', 'processing')">قيد التنفيذ</button>
            <button class="btn-cancel" onclick="updateOrderStatus('${id}', 'cancelled')">إلغاء</button>
        </div>
    `;

    document.getElementById('order-modal').classList.add('active');
}

function closeOrderDetailsModal() {
    document.getElementById('order-modal').classList.remove('active');
}

function updateOrderStatus(id, status) {
    database.ref('orders/' + id + '/status').set(status)
        .then(() => {
            showToast('تم تحديث الحالة');
            closeOrderDetailsModal();
        })
        .catch(err => showToast('حدث خطأ: ' + err.message));
}

function deleteOrder(id) {
    if (!confirm('هل أنت متأكد من حذف هذا الطلب؟')) return;
    database.ref('orders/' + id).remove()
        .then(() => showToast('تم الحذف بنجاح'))
        .catch(err => showToast('حدث خطأ: ' + err.message));
}

// Toast
function showToast(message) {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3000);
}

// ==================== COUPONS ====================
function loadCoupons() {
    database.ref('coupons').on('value', (snapshot) => {
        const coupons = [];
        snapshot.forEach(child => {
            coupons.push({ id: child.key, ...child.val() });
        });
        renderCouponsTable(coupons);
    });
}

function renderCouponsTable(coupons) {
    const tbody = document.getElementById('coupons-table');
    if (coupons.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; color: var(--gray);">لا توجد كوبونات</td></tr>';
        return;
    }

    tbody.innerHTML = coupons.map(coupon => {
        const typeText = coupon.type === 'percentage' ? 'نسبة %' : 'ثابت ج.م';
        const statusClass = coupon.active ? 'status-completed' : 'status-cancelled';
        const statusText = coupon.active ? 'نشط' : 'معطل';
        const expiresText = coupon.expiresAt ? new Date(coupon.expiresAt).toLocaleDateString('ar-EG') : 'لا ينتهي';
        const usesText = coupon.usedCount ? `${coupon.usedCount}/${coupon.maxUses || '∞'}` : `0/${coupon.maxUses || '∞'}`;

        return `
            <tr>
                <td><strong style="font-size: 1.1rem; color: var(--accent);">${coupon.id}</strong></td>
                <td>${typeText}</td>
                <td>${coupon.value}${coupon.type === 'percentage' ? '%' : ' ج.م'}</td>
                <td>${coupon.minOrder || 0} ج.م</td>
                <td>${usesText}</td>
                <td><span class="status-badge ${statusClass}">${statusText}</span></td>
                <td class="table-actions">
                    <button class="btn-edit" onclick="editCoupon('${coupon.id}')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-delete" onclick="deleteCoupon('${coupon.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                    <button class="btn-toggle ${coupon.active ? 'active' : ''}" onclick="toggleCoupon('${coupon.id}')">
                        <i class="fas fa-power-off"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

function openCouponModal() {
    document.getElementById('coupon-id').value = '';
    document.getElementById('coupon-code').value = '';
    document.getElementById('coupon-type').value = 'percentage';
    document.getElementById('coupon-value').value = '';
    document.getElementById('coupon-min-order').value = '0';
    document.getElementById('coupon-max-uses').value = '';
    document.getElementById('coupon-expires').value = '';
    document.getElementById('coupon-active').checked = true;
    document.getElementById('coupon-modal').classList.add('active');
}

function closeCouponModal() {
    document.getElementById('coupon-modal').classList.remove('active');
}

function editCoupon(code) {
    database.ref('coupons/' + code).once('value').then((snapshot) => {
        const coupon = snapshot.val();
        if (!coupon) return;

        document.getElementById('coupon-id').value = code;
        document.getElementById('coupon-code').value = code;
        document.getElementById('coupon-type').value = coupon.type;
        document.getElementById('coupon-value').value = coupon.value;
        document.getElementById('coupon-min-order').value = coupon.minOrder || 0;
        document.getElementById('coupon-max-uses').value = coupon.maxUses || '';
        document.getElementById('coupon-expires').value = coupon.expiresAt || '';
        document.getElementById('coupon-active').checked = coupon.active !== false;
        document.getElementById('coupon-modal').classList.add('active');
    });
}

function deleteCoupon(code) {
    if (!confirm('هل أنت متأكد من حذف هذا الكوبون؟')) return;
    database.ref('coupons/' + code).remove()
        .then(() => showToast('تم الحذف بنجاح'))
        .catch(err => showToast('حدث خطأ: ' + err.message));
}

function toggleCoupon(code) {
    database.ref('coupons/' + code).once('value').then((snapshot) => {
        const coupon = snapshot.val();
        if (!coupon) return;

        const newActive = coupon.active === false ? true : false;
        database.ref('coupons/' + code + '/active').set(newActive)
            .then(() => showToast(newActive ? 'تم تفعيل الكوبون' : 'تم تعطيل الكوبون'))
            .catch(err => showToast('حدث خطأ: ' + err.message));
    });
}

document.getElementById('coupon-form').addEventListener('submit', (e) => {
    e.preventDefault();

    const id = document.getElementById('coupon-id').value;
    const code = document.getElementById('coupon-code').value.trim().toUpperCase();
    const type = document.getElementById('coupon-type').value;
    const value = parseFloat(document.getElementById('coupon-value').value);
    const minOrder = parseFloat(document.getElementById('coupon-min-order').value) || 0;
    const maxUses = parseInt(document.getElementById('coupon-max-uses').value) || null;
    const expiresAt = document.getElementById('coupon-expires').value || null;
    const active = document.getElementById('coupon-active').checked;

    if (!code || !value) {
        showToast('الرجاء ملء جميع الحقول المطلوبة');
        return;
    }

    const couponData = {
        type: type,
        value: value,
        minOrder: minOrder,
        maxUses: maxUses,
        expiresAt: expiresAt,
        active: active,
        usedCount: 0,
        createdAt: new Date().toISOString()
    };

    database.ref('coupons/' + code).set(couponData)
        .then(() => {
            showToast(id ? 'تم التحديث بنجاح' : 'تم إنشاء الكوبون بنجاح');
            closeCouponModal();
        })
        .catch(err => showToast('حدث خطأ: ' + err.message));
});

// Close modals on backdrop click
document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('active');
        }
    });
});
